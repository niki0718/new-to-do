<h1>Todo List Project</h1>

Sample web app, created by HTML, CSS, JavaScript and jQuery. Demonstrating todo list, adding and removing items to it. 


App has hosted in this [URL to the project](https://hummatli.github.io/todo-list-project/)


This app has created on my JavaScript, HTML, CSS, jQuery learning process.

<p align="center">
<img src="https://raw.githubusercontent.com/hummatli/todo-list-project/master/screenshot.png" width="300px"/>
</p>
